import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  myVettore: string[];
  item: string;
  isKanguri : boolean;

  ngOnInit(): void { }

  constructor() {
    this.myVettore = [];
    this.item = "";
    
    this.isKanguri = true;
  }

  addItem() {
    if (this.item.length == 0 || this.myVettore.includes(this.item)) {
      return;
    }
    
    this.myVettore.push(this.item);
  }

  removeItem(): boolean {
    var index: number = 0;
    for (let i of this.myVettore) {
      if (i == this.item) {
         this.myVettore.splice(index,1)
        return true;
      }
      index++;
    }
    return false;
  }
  abilita() {
    if (this.isKanguri == false) {
      this.isKanguri = true
      return;
    }
    this.isKanguri = false;
  }

}
