import { Component } from '@angular/core';
import { HEROES } from './mock-heros';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'angular-tour-of-heros';
}
